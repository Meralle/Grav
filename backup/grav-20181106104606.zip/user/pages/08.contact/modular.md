---
title: Kontakt
media_order: 'img-page-title.jpg,nature1.jpg'
content:
    items: '@self.modular'
    order:
        by: default
        dir: asc
        custom:
            - _contact
            - _map
            - _testimonals
menu: kontact
shown_in_footer: true
background_image: img-page-title.jpg
---

