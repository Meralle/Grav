---
title: 'Servicelösung für Ihr Produkt!'
solutions:
    -
        title: Vor-Ort-Beratung
        description: 'Class aptent taciti estied aliquam ellus pers piciat unde omnis dolorem.'
        image: icon-council.svg
    -
        title: 'Planung und Projecktierung'
        description: 'Class aptent taciti estied aliquam ellus pers piciat unde omnis dolorem.'
        image: icon-inspection.svg
    -
        title: 'montage und installation'
        description: 'Class aptent taciti estied aliquam ellus pers piciat unde omnis dolorem.'
        image: icon-service.svg
    -
        title: Netzanschluss
        description: 'Class aptent taciti estied aliquam ellus pers piciat unde omnis dolorem.'
        image: icon-report.svg
how_heading: Gutachten
hows:
    -
        title: 'Untersuchungen und Hilfe bei der Fehlersuche'
        description: 'Ut cursus massa at urnaaculis estie. Sed aliquamellus vitae ultrs cond mentum leo massa mollis estiegittis miristum nulla.'
    -
        title: 'Aufzeigen von Lösungsmöglichkeiten'
        description: 'Ut cursus massa at urnaaculis estie. Sed aliquamellus vitae ultrs cond mentum leo massa mollis estiegittis miristum nulla.'
    -
        title: Standortanalys
        description: 'Ut cursus massa at urnaaculis estie. Sed aliquamellus vitae ultrs cond mentum leo massa mollis estiegittis miristum nulla.'
    -
        title: Verschattungsanalyse
        description: 'Ut cursus massa at urnaaculis estie. Sed aliquamellus vitae ultrs cond mentum leo massa mollis estiegittis miristum nulla.'
    -
        title: Versicherungsgutachte
        description: 'Ut cursus massa at urnaaculis estie. Sed aliquamellus vitae ultrs cond mentum leo massa mollis estiegittis miristum nulla.'
    -
        title: Schadensgutachte
        description: 'Ut cursus massa at urnaaculis estie. Sed aliquamellus vitae ultrs cond mentum leo massa mollis estiegittis miristum nulla.'
    -
        title: 'Untersuchung von Schadensfällen wie Hagel, Blitzschäden etc'
        description: 'Ut cursus massa at urnaaculis estie. Sed aliquamellus vitae ultrs cond mentum leo massa mollis estiegittis miristum nulla.'
    -
        title: Ertragsprognosen
        description: 'Ut cursus massa at urnaaculis estie. Sed aliquamellus vitae ultrs cond mentum leo massa mollis estiegittis miristum nulla.'
why_heading: 'Why choose our services'
whys:
    -
        title: 'Strategic Plan'
        description: 'Ut cursus massa at urnaaculis estie. Sed aliquamellus vitae ultrs condmentum leo massa mollis estiegittis miristum nulla sed fringilla Donec vitae orci dignissim, faucibus tellus volutpat, rhoncus leo.<br>Mauris in quam tristique, dignissim urna in, molestie felis. Fusce tristique, elit nec vehicula imperdiet, eros est egestas odio, at aliquet elit nulla sed massa. Ut cursus massa at urnaaculis estie.'
    -
        title: 'Annual Budget Plan'
        description: 'Ut cursus massa at urnaaculis estie. Sed aliquamellus vitae ultrs condmentum leo massa mollis estiegittis miristum nulla sed fringilla Donec vitae orci dignissim, faucibus tellus volutpat, rhoncus leo.<br>Mauris in quam tristique, dignissim urna in, molestie felis. Fusce tristique, elit nec vehicula imperdiet, eros est egestas odio, at aliquet elit nulla sed massa. Ut cursus massa at urnaaculis estie.'
    -
        title: 'Include Professional Details'
        description: 'Ut cursus massa at urnaaculis estie. Sed aliquamellus vitae ultrs condmentum leo massa mollis estiegittis miristum nulla sed fringilla Donec vitae orci dignissim, faucibus tellus volutpat, rhoncus leo.<br>Mauris in quam tristique, dignissim urna in, molestie felis. Fusce tristique, elit nec vehicula imperdiet, eros est egestas odio, at aliquet elit nulla sed massa. Ut cursus massa at urnaaculis estie.'
---

