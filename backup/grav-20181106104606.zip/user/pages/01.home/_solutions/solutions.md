---
title: Solutions
solutions:
    -
        title: title1
        description: "hallo there\r\nhallo there\r\nhallo there\r\nhallo there"
        image: icon-council.svg
    -
        title: title2
        description: "hallo there\r\nhallo there\r\nhallo there\r\nhallo there\r\nhallo there"
        image: icon-report.svg
    -
        title: title3
        description: "hallo there\r\nhallo there\r\nhallo there\r\nhallo there\r\nhallo there"
        image: icon-inspection.svg
    -
        title: title4
        description: "hallo there\r\nhallo there\r\nhallo there\r\nhallo there\r\nhallo there"
        image: icon-report.svg
---

<!-- <img src="/user/pages/01.home/_solutions/icon-council.svg" alt="svg picture" width="200">
<img src="/user/pages/01.home/_solutions/icon-council.svg" alt="svg picture" width="200"> -->
<!-- ![](/images/circles.png?cropResize=100,100)
![](/images/icon-council.svg?cropResize=100,100)
![](/images/logo.svg?cropResize=300,300)  -->
<!-- <img src="/user/pages/01.home/_solutions/icon-council.svg" alt="svg picture" width="100">
<img src="/user/pages/01.home/_solutions/icon-inspection.svg" alt="svg picture" width="100">
<img src="/user/pages/01.home/_solutions/icon-service.svg" alt="svg picture" width="100">
<img src="/user/pages/03.services/_solutions/img-offer-33.jpg"> -->


