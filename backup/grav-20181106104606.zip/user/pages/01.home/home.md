---
title: Home
media_order: 'logo_solartester.svg,logo-client-2.jpg,img.jpg'
menu: Startsite
visible: false
shown_in_footer: true
content:
    items: '@self.modular'
    order:
        by: default
        dir: asc
        custom:
            - _carousel
            - _solutions
            - _services
            - _clients
---

<!-- <img src="/user/pages/01.home/_solutions/icon-council.svg" alt="svg picture" width="100">
<img src="/user/pages/01.home/_solutions/icon-inspection.svg" alt="svg picture" width="100">
<img src="/user/pages/01.home/_solutions/icon-service.svg" alt="svg picture" width="100">
<img src="/user/pages/01.home/_solutions/icon-report.svg" alt="svg picture" width="100">
<img src="/images/logo_solartester.svg" alt="svg picture" width="100">
<img src="/user/pages/01.home/_solutions/logo_solartester.svg" alt="svg picture" width="100">  -->
