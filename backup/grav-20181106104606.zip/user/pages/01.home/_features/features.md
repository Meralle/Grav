<!-- ---
title: 'Our Capabilities'
image: img-about.png
features:
    -
        title: 'We teach you how to improve your business'
        icon: fa-line-chart
        description: 'Lorem ipsum dolor sit consectetuer adipiscing elit nonummy ib uismod tincidunt ut laoreet<br>dolore magna aliquam erat volutpat.'
    -
        title: 'We make the technology affordable for you'
        icon: fa-life-ring
        description: 'Lorem ipsum dolor sit consectetuer adipiscing elit nonummy ib uismod tincidunt ut laoreet<br>dolore magna aliquam erat volutpat.'
    -
        title: 'Seamlessly grow wireless human capital before turnkey'
        icon: fa-calculator
        description: 'Lorem ipsum dolor sit consectetuer adipiscing elit nonummy ib uismod tincidunt ut laoreet<br>dolore magna aliquam erat volutpat.'
--- -->

