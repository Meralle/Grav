---
title: Search
published: false
hide_git_sync_repo_link: true
template: search
icon: search
---

This page uses the open source [TNTSearch plugin](https://github.com/trilbymedia/grav-plugin-tntsearch) and includes the ability for fuzzy (i.e. approximate) searches.
