---
title: 'Embedly Card'
embedly_card_title: 'Embedly makes your content more engaging and easier to share | Embedly'
embedly_card_alignment: left
embedly_card_url: 'http://embed.ly/'
published: true
visible: false
---

** Example Embed.ly Card **
