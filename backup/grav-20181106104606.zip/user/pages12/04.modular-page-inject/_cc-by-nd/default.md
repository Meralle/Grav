---
title: CC-BY-ND
---

**CC-BY-ND**  
Creative Commons Attribution-No derivatives license. OER licensed CC-BY-ND may or may not be shared in the same manner, can be used commercially, but credit must be given to the author and it cannot be modified.
