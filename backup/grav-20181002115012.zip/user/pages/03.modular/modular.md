---
title: Modular
content:
    items: '@self.modular'
body_classes: modular
---

